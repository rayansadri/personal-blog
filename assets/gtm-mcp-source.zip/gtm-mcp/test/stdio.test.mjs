import test from "node:test";
import assert from "node:assert/strict";
import { Client } from "@modelcontextprotocol/sdk/client/index.js";
import { StdioClientTransport } from "@modelcontextprotocol/sdk/client/stdio.js";
import { mkdtempSync, rmSync } from "node:fs";
import { tmpdir } from "node:os";
import { join, resolve } from "node:path";
import { Store } from "../dist/store.js";
test("official MCP client exercises all seven tools over stdio", async (t) => {
  const dir = mkdtempSync(join(tmpdir(), "gtm-protocol-"));
  const transport = new StdioClientTransport({
    command: process.execPath,
    args: [resolve("dist/cli.js"), "serve", "--stdio"],
    env: { ...process.env, GTM_HOME: dir },
    stderr: "pipe",
  });
  const client = new Client({ name: "integration-test", version: "1.0.0" });
  t.after(async () => {
    await client.close();
    rmSync(dir, { recursive: true, force: true });
  });
  await client.connect(transport);
  const tools = await client.listTools();
  assert.equal(tools.tools.length, 7);
  const call = (name, args) => client.callTool({ name, arguments: args });
  const search = await call("search_companies", { query: "healthcare AI" });
  assert.equal(search.structuredContent.total, 10);
  for (const name of ["enrich_company", "score_company", "get_crm_context"])
    assert(!(await call(name, { companyId: "meridian" })).isError);
  assert.equal(
    (
      await call("draft_outreach", {
        companyId: "meridian",
        offer: "workflow review",
      })
    ).structuredContent.sent,
    false,
  );
  const p = (
    await call("propose_crm_update", {
      companyId: "meridian",
      status: "qualified",
      note: "test",
    })
  ).structuredContent.proposal;
  assert((await call("commit_crm_update", { proposalId: p.id })).isError);
  new Store(dir).decide(p.id, true);
  assert(!(await call("commit_crm_update", { proposalId: p.id })).isError);
  assert.equal(
    (await call("get_crm_context", { companyId: "meridian" })).structuredContent
      .record.version,
    1,
  );
  assert((await call("score_company", { companyId: 123 })).isError);
});
