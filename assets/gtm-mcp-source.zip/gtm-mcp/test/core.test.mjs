import test from "node:test";
import assert from "node:assert/strict";
import { mkdtempSync, rmSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { Engine, schemas } from "../dist/tools.js";
import { Store } from "../dist/store.js";
import { companies, score } from "../dist/data.js";
import { runDemo } from "../dist/demo.js";
import { spawnSync } from "node:child_process";
const setup = (t) => {
  const dir = mkdtempSync(join(tmpdir(), "gtm-test-"));
  t.after(() => rmSync(dir, { recursive: true, force: true }));
  return new Engine(new Store(dir));
};
const propose = (e) =>
  e.call("propose_crm_update", {
    companyId: "meridian",
    status: "qualified",
    note: "test",
  }).proposal;
test("seven strict schemas reject invalid arguments", (t) => {
  const e = setup(t);
  assert.equal(Object.keys(schemas).length, 7);
  for (const s of Object.values(schemas))
    assert.equal(s.safeParse({ garbage: true }).success, false);
  assert.throws(() => e.call("search_companies", { query: "AI", limit: 100 }));
  assert.throws(() =>
    e.call("commit_crm_update", { proposalId: "x", approved: true }),
  );
});
test("scores calculate documented criteria and bounds", () => {
  assert.equal(score(companies[0]).score, 100);
  assert.equal(score(companies[1]).score, 95);
  assert.equal(
    score({
      ...companies[0],
      industry: "retail",
      employees: 1,
      region: "Mars",
      stage: "Public",
      signals: [],
    }).score,
    0,
  );
  for (const c of companies) {
    const s = score(c);
    assert.equal(
      s.criteria.reduce((a, x) => a + x.points, 0),
      s.score,
    );
    assert(s.score >= 0 && s.score <= 100);
  }
});
test("search filters, unknown accounts rejected and drafts never send", (t) => {
  const e = setup(t);
  assert.equal(
    e.call("search_companies", { query: "healthcare AI" }).total,
    10,
  );
  assert.equal(e.call("search_companies", { query: "retail" }).total, 0);
  assert.throws(() => e.call("enrich_company", { companyId: "missing" }));
  assert.equal(
    e.call("draft_outreach", {
      companyId: "meridian",
      offer: "workflow review",
    }).sent,
    false,
  );
});
test("approval required, exact payload commits once and persists", (t) => {
  const e = setup(t),
    p = propose(e);
  assert.throws(
    () => e.call("commit_crm_update", { proposalId: p.id }),
    /approval/,
  );
  e.store.decide(p.id, true);
  e.call("commit_crm_update", { proposalId: p.id });
  assert.throws(() => e.call("commit_crm_update", { proposalId: p.id }));
  assert.equal(new Store(e.store.dir).read().crm.meridian.version, 1);
});
test("rejected, expired, stale and tampered proposals cannot commit", (t) => {
  const e = setup(t);
  let p = propose(e);
  e.store.decide(p.id, false);
  assert.throws(() => e.call("commit_crm_update", { proposalId: p.id }));
  p = propose(e);
  e.store.decide(p.id, true);
  e.store.transaction((s) => (s.proposals[p.id].expires = 0));
  assert.throws(
    () => e.call("commit_crm_update", { proposalId: p.id }),
    /expired/,
  );
  p = propose(e);
  e.store.decide(p.id, true);
  e.store.transaction((s) => (s.proposals[p.id].payload.note = "changed"));
  assert.throws(
    () => e.call("commit_crm_update", { proposalId: p.id }),
    /integrity/,
  );
  const a = propose(e),
    b = propose(e);
  e.store.decide(a.id, true);
  e.store.decide(b.id, true);
  e.call("commit_crm_update", { proposalId: a.id });
  assert.throws(
    () => e.call("commit_crm_update", { proposalId: b.id }),
    /Stale/,
  );
});
test("demo computes ten scores, three drafts, pending proposal and no writes", async (t) => {
  const e = setup(t);
  const r = await runDemo(e);
  assert.equal(r.ranked.length, 10);
  assert.equal(r.drafts.length, 3);
  assert.equal(r.proposal.proposal.state, "pending");
  assert.deepEqual(e.store.read().crm, {});
  assert.equal(e.store.read().logs.length, 25);
});
test("piped human approval is refused", (t) => {
  const e = setup(t),
    p = propose(e);
  const r = spawnSync(process.execPath, ["dist/cli.js", "approve", p.id], {
    env: { ...process.env, GTM_HOME: e.store.dir },
    input: `approve ${p.id}\n`,
    encoding: "utf8",
  });
  assert.equal(r.status, 1);
  assert.match(r.stderr, /interactive terminal/);
  assert.equal(e.store.read().proposals[p.id].state, "pending");
});
