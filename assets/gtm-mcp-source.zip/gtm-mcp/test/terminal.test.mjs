import test from "node:test";
import assert from "node:assert/strict";
import { spawn } from "node-pty";
import { mkdtempSync, rmSync, existsSync, chmodSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { Engine } from "../dist/tools.js";
import { Store } from "../dist/store.js";
const helper = `node_modules/node-pty/prebuilds/${process.platform}-${process.arch}/spawn-helper`;
if (process.platform === "darwin" && existsSync(helper))
  chmodSync(helper, 0o755);
function session(args, dir, react, cols = 126) {
  return new Promise((resolve, reject) => {
    const p = spawn(process.execPath, ["dist/cli.js", ...args], {
      cols,
      rows: 50,
      cwd: process.cwd(),
      name: "xterm-256color",
      env: { ...process.env, GTM_HOME: dir },
    });
    let text = "";
    const timer = setTimeout(() => {
      p.kill();
      reject(new Error("PTY timeout: " + text.slice(-600)));
    }, 8000);
    p.onData((data) => {
      text += data;
      react(data, p, text);
    });
    p.onExit(({ exitCode }) => {
      clearTimeout(timer);
      exitCode === 0 ? resolve(text) : reject(new Error(text));
    });
  });
}
test("real terminal approval and commit end to end", async (t) => {
  const dir = mkdtempSync(join(tmpdir(), "gtm-human-"));
  t.after(() => rmSync(dir, { recursive: true, force: true }));
  const e = new Engine(new Store(dir));
  const p = e.call("propose_crm_update", {
    companyId: "meridian",
    status: "qualified",
    note: "PTY approval test",
  }).proposal;
  let sent = false;
  await session(["approve", p.id], dir, (data, pty, text) => {
    if (!sent && text.includes("exact local CRM payload:")) {
      sent = true;
      pty.write(`approve ${p.id}\r`);
    }
  });
  assert.equal(e.store.read().proposals[p.id].state, "approved");
  assert.equal(
    e.call("commit_crm_update", { proposalId: p.id }).record.version,
    1,
  );
});
test("Ink keyboard navigation renders and exits at narrow terminal width", async (t) => {
  const dir = mkdtempSync(join(tmpdir(), "gtm-ink-"));
  t.after(() => rmSync(dir, { recursive: true, force: true }));
  let phase = 0;
  const text = await session(
    ["demo"],
    dir,
    (_, pty, text) => {
      if (phase === 0 && text.includes("tab views")) {
        phase = 1;
        setTimeout(() => pty.write("\t"), 200);
      } else if (phase === 1 && text.includes("[Plan]")) {
        phase = 2;
        setTimeout(() => pty.write("q"), 100);
      }
    },
    64,
  );
  assert.match(text, /Meridian AI/);
  assert.match(text, /LOCAL FIXTURES/);
  assert.equal(phase, 2);
});
