#!/usr/bin/env node
import React from "react";
import { render } from "ink";
import { createInterface } from "node:readline/promises";
import { Engine, schemas, descriptions, type ToolName } from "./tools.js";
import { runDemo } from "./demo.js";
import { LiveTerminal } from "./ui.js";
import { serve } from "./server.js";
const [command, ...args] = process.argv.slice(2);
const print = (o: unknown) => console.log(JSON.stringify(o, null, 2));
async function main() {
  if (command === "serve") {
    if (args.join(" ") !== "--stdio") throw new Error("Use serve --stdio");
    await serve();
    return;
  }
  const engine = new Engine();
  if (command === "demo") {
    const interactive =
      !!process.stdin.isTTY &&
      !!process.stdout.isTTY &&
      !args.includes("--plain");
    if (interactive) {
      await render(<LiveTerminal engine={engine} />).waitUntilExit();
    } else print(await runDemo(engine, (line) => console.log(`+ ${line}`)));
    return;
  }
  if (command === "tools") {
    print(
      Object.keys(schemas).map((name) => ({
        name,
        description: descriptions[name as ToolName],
      })),
    );
    return;
  }
  if (command === "inspect") {
    print({
      enrichment: engine.call("enrich_company", { companyId: args.join(" ") }),
      scoring: engine.call("score_company", { companyId: args.join(" ") }),
      crm: engine.call("get_crm_context", { companyId: args.join(" ") }),
    });
    return;
  }
  if (command === "logs") {
    print(engine.store.read().logs);
    return;
  }
  if (command === "approve" || command === "reject") {
    if (!process.stdin.isTTY || !process.stdout.isTTY)
      throw new Error(
        "Human review requires an interactive terminal. Piped approval is not accepted.",
      );
    const p = engine.store.read().proposals[args[0]];
    if (!p) throw new Error("Unknown proposal");
    print(p);
    const rl = createInterface({
      input: process.stdin,
      output: process.stdout,
    });
    try {
      const answer = await rl.question(
        `Type ${command} ${p.id} to ${command} this exact local CRM payload: `,
      );
      if (answer !== `${command} ${p.id}`)
        throw new Error("Cancelled; no decision recorded");
      print(engine.store.decide(p.id, command === "approve"));
    } finally {
      rl.close();
    }
    return;
  }
  if (command === "commit") {
    print(engine.call("commit_crm_update", { proposalId: args[0] }));
    return;
  }
  if (command === "call") {
    const name = args[0] as ToolName;
    if (!Object.hasOwn(schemas, name)) throw new Error("Unknown tool");
    print(engine.call(name, JSON.parse(args[1] || "{}")));
    return;
  }
  if (command && command !== "help")
    throw new Error(`Unknown command: ${command}`);
  console.log(
    "GTM MCP / local-first account tools\n\ngtmctl demo [--plain]\ngtmctl tools\ngtmctl inspect <company>\ngtmctl serve --stdio\ngtmctl logs\ngtmctl call <tool> <json>\ngtmctl approve|reject <proposalId>\ngtmctl commit <proposalId>\n\nFictional fixtures only. No external integrations connected.",
  );
}
main().catch((e) => {
  console.error(e instanceof Error ? e.message : e);
  process.exitCode = 1;
});
