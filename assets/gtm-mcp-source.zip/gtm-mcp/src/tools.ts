import { z } from "zod";
import { randomUUID } from "node:crypto";
import { companies, company, score } from "./data.js";
import { Store, hash, type Payload } from "./store.js";
const id = z.string().min(1).max(100);
export const schemas = {
  search_companies: z
    .object({
      query: z.string().min(1).max(200),
      limit: z.number().int().min(1).max(10).default(10),
    })
    .strict(),
  enrich_company: z.object({ companyId: id }).strict(),
  score_company: z.object({ companyId: id }).strict(),
  get_crm_context: z.object({ companyId: id }).strict(),
  draft_outreach: z
    .object({ companyId: id, offer: z.string().min(1).max(400) })
    .strict(),
  propose_crm_update: z
    .object({
      companyId: id,
      status: z.enum(["researched", "qualified"]),
      note: z.string().max(1000),
    })
    .strict(),
  commit_crm_update: z.object({ proposalId: z.string().uuid() }).strict(),
};
export type ToolName = keyof typeof schemas;
export const descriptions: Record<ToolName, string> = {
  search_companies:
    "Search the fictional local account dataset. No web search.",
  enrich_company: "Retrieve fixture firmographics and source provenance.",
  score_company:
    "Score against documented healthcare-v1 criteria with breakdown.",
  get_crm_context: "Read local demo CRM context.",
  draft_outreach:
    "Prepare a deterministic outreach template. Does not send email or call an LLM.",
  propose_crm_update:
    "Stage an immutable local CRM payload for separate human review.",
  commit_crm_update:
    "Commit a proposal ONLY after local terminal human approval. Cannot approve.",
};
export class Engine {
  constructor(public store = new Store()) {}
  call(name: ToolName, input: unknown): Record<string, unknown> {
    if (!Object.hasOwn(schemas, name)) throw new Error("Unknown tool");
    const args = schemas[name].parse(input) as Record<string, any>;
    return this.store.transaction((s) => {
      let output: Record<string, unknown>;
      if (name === "search_companies") {
        const terms = args.query.toLowerCase().split(/\s+/);
        const matches = companies
          .filter((c) =>
            terms.every((t: string) =>
              `${c.name} ${c.industry} ${c.region}`.toLowerCase().includes(t),
            ),
          )
          .slice(0, args.limit);
        output = {
          companies: matches,
          total: matches.length,
          source: "fictional fixture",
          connectors: "none",
        };
      } else if (name === "commit_crm_update") {
        const p = s.proposals[args.proposalId];
        if (!p || p.state !== "approved")
          throw new Error(
            "Human approval required: run gtmctl approve <proposalId> in a trusted terminal.",
          );
        if (p.expires < Date.now()) throw new Error("Proposal expired");
        if (hash(p.payload) !== p.digest)
          throw new Error("Payload integrity check failed");
        if ((s.crm[p.payload.companyId]?.version || 0) !== p.version)
          throw new Error("Stale proposal: CRM changed; propose again");
        s.crm[p.payload.companyId] = { ...p.payload, version: p.version + 1 };
        p.state = "committed";
        output = {
          proposalId: p.id,
          record: s.crm[p.payload.companyId],
          destination: "local demo CRM",
        };
      } else {
        const c = company(args.companyId);
        if (name === "enrich_company")
          output = {
            company: c,
            source: "fictional fixture",
            externalRequests: 0,
          };
        else if (name === "score_company") output = score(c);
        else if (name === "get_crm_context")
          output = {
            companyId: c.id,
            record: s.crm[c.id] || null,
            source: "local demo CRM",
          };
        else if (name === "draft_outreach")
          output = {
            companyId: c.id,
            subject: `A workflow idea for ${c.name}`,
            body: `Hi ${c.name} team,\n\nI am exploring ${args.offer}. Your focus on ${c.industry} caught my attention. Would it be useful to compare workflows?\n\nRayan`,
            method: "deterministic template",
            sent: false,
            source: "fictional fixture",
          };
        else {
          const payload: Payload = {
            companyId: c.id,
            status: args.status,
            note: args.note,
          };
          const proposalId = randomUUID();
          s.proposals[proposalId] = {
            id: proposalId,
            payload,
            digest: hash(payload),
            version: s.crm[c.id]?.version || 0,
            state: "pending",
            created: Date.now(),
            expires: Date.now() + 900_000,
          };
          output = {
            proposal: s.proposals[proposalId],
            next: `gtmctl approve ${proposalId}`,
            destination: "local demo CRM",
          };
        }
      }
      s.logs.push({
        time: new Date().toISOString(),
        tool: name,
        ok: true,
        output,
      });
      return output;
    });
  }
}
