import { McpServer } from "@modelcontextprotocol/sdk/server/mcp.js";
import { StdioServerTransport } from "@modelcontextprotocol/sdk/server/stdio.js";
import { Engine, schemas, descriptions, type ToolName } from "./tools.js";
export function createServer(engine = new Engine()) {
  const server = new McpServer({ name: "gtm-mcp", version: "0.1.0" });
  for (const name of Object.keys(schemas) as ToolName[])
    server.registerTool(
      name,
      {
        description: descriptions[name],
        inputSchema: schemas[name].shape,
        annotations: {
          readOnlyHint: !["propose_crm_update", "commit_crm_update"].includes(
            name,
          ),
          openWorldHint: false,
          destructiveHint: name === "commit_crm_update",
        },
      },
      async (args: Record<string, unknown>) => {
        try {
          const output = engine.call(name, args);
          return {
            content: [
              { type: "text" as const, text: JSON.stringify(output, null, 2) },
            ],
            structuredContent: output,
          };
        } catch (e) {
          return {
            isError: true,
            content: [
              {
                type: "text" as const,
                text: e instanceof Error ? e.message : "Tool failed",
              },
            ],
          };
        }
      },
    );
  return server;
}
export async function serve() {
  await createServer().connect(new StdioServerTransport());
}
