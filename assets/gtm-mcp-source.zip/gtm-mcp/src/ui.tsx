import React, { useState, useEffect } from "react";
import { Box, Text, useInput, useApp, useStdout } from "ink";
import { runDemo } from "./demo.js";
import { schemas, Engine } from "./tools.js";
export function LiveTerminal({ engine }: { engine: Engine }) {
  const [result, setResult] = useState<Awaited<ReturnType<typeof runDemo>>>();
  const [lines, setLines] = useState<string[]>([]);
  const [error, setError] = useState("");
  const { exit } = useApp();
  useInput((input, key) => {
    if (!result && (input === "q" || key.escape)) exit();
  }, { isActive: !result });
  useEffect(() => {
    let active = true;
    runDemo(engine, async (line) => {
      if (active) setLines((l) => [...l, line]);
      await new Promise((r) => setTimeout(r, 180));
    })
      .then((r) => {
        if (active) setResult(r);
      })
      .catch((e) => {
        if (active) setError(String(e));
      });
    return () => {
      active = false;
    };
  }, [engine]);
  if (result) return <Terminal result={result} />;
  return (
    <Box
      borderStyle="round"
      borderColor="#b995ff"
      padding={1}
      flexDirection="column"
    >
      <Text bold color="#b995ff">
        &gt; GTM MCP_ / executing local tools
      </Text>
      {lines.map((l) => (
        <Text key={l} color="#81dda6">
          + {l}
        </Text>
      ))}
      <Text>{error ? `${error} / q to exit` : "Running deterministic fixture pipeline..."}</Text>
    </Box>
  );
}
export function Terminal({
  result,
}: {
  result: Awaited<ReturnType<typeof runDemo>>;
}) {
  const { stdout } = useStdout();
  const [width, setWidth] = useState(stdout.columns || 100);
  useEffect(() => {
    const resize = () => setWidth(stdout.columns || 100);
    stdout.on("resize", resize);
    return () => {
      stdout.off("resize", resize);
    };
  }, [stdout]);
  const [tab, setTab] = useState(0);
  const [row, setRow] = useState(0);
  const { exit } = useApp();
  useInput((input, key) => {
    if (input === "q" || key.escape) exit();
    if (key.tab) setTab((v) => (v + (key.shift ? 3 : 1)) % 4);
    if (key.downArrow) setRow((v) => (v + 1) % result.ranked.length);
    if (key.upArrow) setRow((v) => (v + result.ranked.length - 1) % result.ranked.length);
  });
  const selected = result.ranked[row];
  const proposal = result.proposal.proposal as { id: string };
  return (
    <Box
      flexDirection="column"
      borderStyle="round"
      borderColor="#685984"
      paddingX={2}
      paddingY={1}
    >
      <Box justifyContent="space-between">
        <Text color="#b995ff" bold>
          {" "}
          &gt; GTM MCP_
        </Text>
        <Text dimColor>LOCAL FIXTURES / NO CONNECTORS</Text>
      </Box>
      <Box marginY={1} borderStyle="single" borderColor="#b995ff" paddingX={1}>
        <Text>
          Find healthcare AI accounts. Enrich, score, prepare outreach.
        </Text>
      </Box>
      <Box flexDirection={width < 90 ? "column" : "row"}>
        <Box flexDirection="column" flexGrow={1}>
          <Text color="#81dda6">{`+ search_companies  ${result.ranked.length} results`}</Text>
          <Text color="#81dda6">{`+ enrich_company    ${result.ranked.length} enriched`}</Text>
          <Text color="#81dda6">{`+ score_company     ${result.ranked.length} ranked`}</Text>
          <Text color="#81dda6">{`+ draft_outreach    ${result.drafts.length} drafts ready`}</Text>
          <Box marginTop={1} flexDirection="column">
            <Text dimColor>{`     ${'COMPANY'.padEnd(23)} ICP`}</Text>
            {result.ranked.map((c, i) => (
              <Text
                key={c.id}
                color={i === row ? "#d6baff" : undefined}
                backgroundColor={i === row ? "#302044" : undefined}
              >{`${i === row ? ">" : " "} ${String(i + 1).padStart(2, "0")} ${c.name.padEnd(23)} ${String(c.score).padStart(3)}`}</Text>
            ))}
          </Box>
        </Box>
        <Box
          width={width < 90 ? "100%" : "45%"}
          flexDirection="column"
          borderLeft
          paddingLeft={2}
          borderColor="#685984"
        >
          <Text color="#b995ff">
            {["Tools", "Plan", "Output", "Logs"]
              .map((t, i) => (i === tab ? `[${t}]` : t))
              .join("  ")}
          </Text>
          <Box marginTop={1} flexDirection="column">
            {tab === 0 ? (
              Object.keys(schemas).map((t) => <Text key={t}>◇ {t}</Text>)
            ) : tab === 1 ? (
              <Text>
                {
                  "search -> enrich -> score\n  -> draft -> propose\n  -> HUMAN -> commit\n\nPolicy: healthcare-v1\nLocal CRM only."
                }
              </Text>
            ) : tab === 2 ? (
              <Box flexDirection="column">
                <Text>{JSON.stringify({companyId:selected.id,name:selected.name,score:selected.score,policy:'healthcare-v1'}, null, 2)}</Text>
                <Text dimColor>{result.drafts.some(d=>d.companyId===selected.id) ? 'Outreach template prepared / not sent' : 'No outreach drafted for this account'}</Text>
                <Text dimColor>{`Full criteria: gtmctl inspect ${selected.id}`}</Text>
              </Box>
            ) : (
              <Box flexDirection="column">
                <Text dimColor>Latest executed calls</Text>
                {result.logs.slice(-7).map((log,i)=><Text key={`${log.time}-${i}`} color={log.ok?'#81dda6':'#ef7575'}>{`${log.time.slice(11,19)} ${log.tool}`}</Text>)}
                <Text dimColor>Full structured outputs: gtmctl logs</Text>
              </Box>
            )}
          </Box>
        </Box>
      </Box>
      <Box marginTop={1} flexDirection="column">
        <Text color="#dfbd75">
          ! CRM write requires separate human approval
        </Text>
        <Text wrap="wrap">gtmctl approve {proposal.id}</Text>
        <Text dimColor>
          tab views / ↑↓ accounts / q exit · gtmctl inspect meridian for full
          outputs
        </Text>
      </Box>
    </Box>
  );
}
