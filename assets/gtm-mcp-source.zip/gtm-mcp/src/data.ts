export type Company = {
  id: string;
  name: string;
  industry: string;
  employees: number;
  region: string;
  stage: string;
  signals: string[];
  domain: string;
};
// Entire fixture is fictional, including names, domains and buying signals.
export const companies: Company[] = [
  ["meridian", "Meridian AI", 120, "US", "Series A", ["hiring", "api"]],
  ["helix", "Helix Health", 80, "Canada", "Seed", ["api"]],
  ["neural", "Neural Labs", 240, "US", "Series B", ["hiring"]],
  ["pulse", "Pulse Research", 40, "UK", "Seed", ["api", "hiring"]],
  ["atlas", "Atlas Imaging", 320, "Canada", "Series A", ["api"]],
  ["lumen", "Lumen Clinical", 90, "Germany", "Series A", ["hiring"]],
  ["cedar", "Cedar Health AI", 18, "US", "Seed", ["api"]],
  ["orbit", "Orbit Diagnostics", 160, "France", "Series B", []],
  ["forma", "Forma Medical", 70, "Canada", "Seed", []],
  ["north", "North Clinical AI", 600, "US", "Series C", ["api", "hiring"]],
].map(([id, name, employees, region, stage, signals]) => ({
  id: id as string,
  name: name as string,
  employees: employees as number,
  region: region as string,
  stage: stage as string,
  signals: signals as string[],
  industry: "healthcare AI",
  domain: `${id}.example`,
}));
export function company(id: string) {
  const c = companies.find(
    (c) => c.id === id || c.name.toLowerCase() === id.toLowerCase(),
  );
  if (!c) throw new Error("Unknown fictional company");
  return c;
}
export function score(c: Company) {
  const criteria = [
    {
      criterion: "Healthcare AI industry",
      points: c.industry === "healthcare AI" ? 30 : 0,
      max: 30,
    },
    {
      criterion: "20-250 employees",
      points: c.employees >= 20 && c.employees <= 250 ? 25 : 0,
      max: 25,
    },
    {
      criterion: "US or Canada",
      points: ["US", "Canada"].includes(c.region) ? 20 : 0,
      max: 20,
    },
    {
      criterion: "Seed or Series A",
      points: ["Seed", "Series A"].includes(c.stage) ? 15 : 0,
      max: 15,
    },
    {
      criterion: "Hiring signal",
      points: c.signals.includes("hiring") ? 5 : 0,
      max: 5,
    },
    {
      criterion: "API signal",
      points: c.signals.includes("api") ? 5 : 0,
      max: 5,
    },
  ];
  return {
    companyId: c.id,
    score: criteria.reduce((sum, c) => sum + c.points, 0),
    criteria,
    policy: "healthcare-v1",
    source: "fictional fixture",
  };
}
