import {
  mkdirSync,
  readFileSync,
  writeFileSync,
  renameSync,
  rmSync,
  existsSync,
} from "node:fs";
import { join } from "node:path";
import { homedir } from "node:os";
import { createHash, randomUUID } from "node:crypto";
export type Payload = {
  companyId: string;
  status: "researched" | "qualified";
  note: string;
};
export type Proposal = {
  id: string;
  payload: Payload;
  digest: string;
  version: number;
  state: "pending" | "approved" | "rejected" | "committed";
  created: number;
  expires: number;
};
export type State = {
  crm: Record<string, Payload & { version: number }>;
  proposals: Record<string, Proposal>;
  logs: { time: string; tool: string; ok: boolean; output: unknown }[];
};
export const hash = (p: Payload) =>
  createHash("sha256").update(JSON.stringify(p)).digest("hex");
export class Store {
  constructor(
    public dir = process.env.GTM_HOME || join(homedir(), ".gtm-mcp"),
  ) {
    mkdirSync(dir, { recursive: true, mode: 0o700 });
  }
  read(): State {
    const f = join(this.dir, "state.json");
    return existsSync(f)
      ? JSON.parse(readFileSync(f, "utf8"))
      : { crm: {}, proposals: {}, logs: [] };
  }
  transaction<T>(fn: (s: State) => T): T {
    const lock = join(this.dir, "write.lock");
    try {
      mkdirSync(lock);
    } catch {
      throw new Error(
        "Store busy. Retry; if a crashed process left write.lock, remove it only after checking no GTM process is running.",
      );
    }
    const tmp = join(this.dir, `${randomUUID()}.tmp`);
    try {
      const s = this.read();
      const result = fn(s);
      s.logs = s.logs.slice(-500);
      writeFileSync(tmp, JSON.stringify(s, null, 2), { mode: 0o600 });
      renameSync(tmp, join(this.dir, "state.json"));
      return result;
    } finally {
      rmSync(tmp, { force: true });
      rmSync(lock, { recursive: true, force: true });
    }
  }
  decide(id: string, approve: boolean) {
    return this.transaction((s) => {
      const p = s.proposals[id];
      if (!p || p.state !== "pending" || p.expires < Date.now())
        throw new Error("Proposal missing, expired or already decided");
      if (hash(p.payload) !== p.digest) throw new Error("Payload changed");
      p.state = approve ? "approved" : "rejected";
      s.logs.push({
        time: new Date().toISOString(),
        tool: "human_decision",
        ok: true,
        output: { id, state: p.state, digest: p.digest },
      });
      return p;
    });
  }
}
