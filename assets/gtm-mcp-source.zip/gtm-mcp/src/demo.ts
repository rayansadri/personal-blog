import { Engine } from "./tools.js";
import { type Company } from "./data.js";
export async function runDemo(
  engine: Engine,
  onTrace: (line: string) => void | Promise<void> = () => {},
) {
  const search = engine.call("search_companies", {
    query: "healthcare AI",
    limit: 10,
  });
  await onTrace(`search_companies  ${search.total} fictional accounts`);
  const ranked = (search.companies as Company[])
    .map((c) => {
      engine.call("enrich_company", { companyId: c.id });
      return {
        id: c.id,
        name: c.name,
        ...engine.call("score_company", { companyId: c.id }),
      } as { id: string; name: string; score: number };
    })
    .sort((a, b) => b.score - a.score || a.name.localeCompare(b.name));
  await onTrace("enrich_company   10 fixture records");
  await onTrace("score_company    10 scored / healthcare-v1");
  const drafts = ranked
    .slice(0, 3)
    .map((c) =>
      engine.call("draft_outreach", {
        companyId: c.id,
        offer: "research and qualification automation",
      }),
    );
  await onTrace("draft_outreach   3 templates / nothing sent");
  const proposal = engine.call("propose_crm_update", {
    companyId: ranked[0].id,
    status: "qualified",
    note: "Reviewed fixture ICP match.",
  });
  await onTrace("propose_crm_update  awaiting HUMAN approval");
  return { ranked, drafts, proposal, logs: engine.store.read().logs.slice(-25) };
}
