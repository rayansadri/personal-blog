// Record the real Ink process through a PTY, then rasterize its terminal cells.
import { spawn } from "../../gtm-mcp/node_modules/node-pty/lib/index.js";
import {
  mkdtempSync,
  mkdirSync,
  writeFileSync,
  rmSync,
  existsSync,
  chmodSync,
} from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";
import xterm from "../../gtm-mcp/node_modules/@xterm/headless/lib-headless/xterm-headless.js";
import {createRequire} from 'node:module';
const require=createRequire(new URL('../../gtm-mcp/package.json',import.meta.url));
const sharp=require('sharp');
const dir = mkdtempSync(join(tmpdir(), "ucp-capture-"));
mkdirSync("docs", { recursive: true });
const cols = 126,
  rows = 48;
const terminal = new xterm.Terminal({ cols, rows, allowProposedApi: true });
// Some node-pty macOS prebuilt packages omit the helper's executable bit.
const helper = `../gtm-mcp/node_modules/node-pty/prebuilds/${process.platform}-${process.arch}/spawn-helper`;
if (process.platform === "darwin" && existsSync(helper))
  chmodSync(helper, 0o755);
const events = [];
const started = Date.now();
const env = {
  ...process.env,
  UCP_TRACE_DIR: dir,
  TERM: "xterm-256color",
  FORCE_COLOR: "3",
};
delete env.NO_COLOR;
const child = spawn(process.execPath, ["dist/cli.js", "demo"], {
  cols,
  rows,
  name: "xterm-256color",
  cwd: process.cwd(),
  env,
});
let snapshot = "";
const escape = (s) =>
  s.replaceAll("&", "&amp;").replaceAll("<", "&lt;").replaceAll(">", "&gt;");
const consume = (data) => {
  const text = data.toString();
  events.push([(Date.now() - started) / 1000, "o", text]);
  terminal.write(text);
};
child.onData(consume);
await new Promise((r) => setTimeout(r, 2200));
await new Promise((r) => terminal.write("", r));
const palette = [
  "#0b0d12",
  "#ef7575",
  "#81dda6",
  "#dfbd75",
  "#83b9f8",
  "#b995ff",
  "#87d3dd",
  "#dddfe7",
];
const ansi = (value) => {
  if (value === 8) return '#858293';
  if (value < 16) return palette[value % 8];
  if (value >= 232) {
    const g = 8 + (value - 232) * 10;
    return `rgb(${g},${g},${g})`;
  }
  const n = value - 16,
    v = [0, 95, 135, 175, 215, 255];
  return `rgb(${v[Math.floor(n / 36)]},${v[Math.floor(n / 6) % 6]},${v[n % 6]})`;
};
const color = (cell, bg) => {
  const mode = bg ? cell.getBgColorMode() : cell.getFgColorMode(),
    value = bg ? cell.getBgColor() : cell.getFgColor();
  return mode === 0
    ? bg
      ? "#0b0d12"
      : "#dddfe7"
    : mode === 0x3000000
      ? `#${value.toString(16).padStart(6, "0")}`
      : ansi(value);
};
let cells = "";
for (let y = 0; y < rows; y++) {
  const line = terminal.buffer.active.getLine(y);
  if (!line) continue;
  for (let x = 0; x < cols; x++) {
    const c = line.getCell(x);
    if (!c) continue;
    const ch = c.getChars();
    if (c.getBgColorMode())
      cells += `<rect x="${32 + x * 10}" y="${66 + y * 22}" width="10" height="22" fill="${color(c, true)}"/>`;
    if (ch)
      cells += `<text x="${32 + x * 10}" y="${83 + y * 22}" fill="${color(c, false)}">${escape(ch)}</text>`;
  }
}
snapshot = `<svg xmlns="http://www.w3.org/2000/svg" width="1324" height="1154"><rect width="1324" height="1154" rx="12" fill="#0b0d12"/><rect x="1" y="1" width="1322" height="1152" rx="12" fill="none" stroke="#514760"/><path d="M0 48H1324" stroke="#34313e"/><circle cx="26" cy="25" r="6" fill="#ed6a5e"/><circle cx="47" cy="25" r="6" fill="#f4bf50"/><circle cx="68" cy="25" r="6" fill="#61c454"/><g font-family="Menlo,monospace" font-size="16"><text x="520" y="31" fill="#a7a1b6">ucp-inspector / demo</text>${cells}<text x="32" y="1134" fill="#868191">ACTUAL INK CAPTURE / OFFLINE CHECKOUT / NO ORDERS</text></g></svg>`;
for (const key of ["j", "k", "r", "9", "d"]) {
  child.write(key);
  await new Promise((r) => setTimeout(r, 2500));
}
child.write("q");
await new Promise((resolve, reject) => {
  const timer = setTimeout(() => {
    child.kill();
    reject(
      new Error(
        "Demo failed to exit: " +
          events
            .map((e) => e[2])
            .join("")
            .slice(-2000),
      ),
    );
  }, 5000);
  child.onExit(({ exitCode }) => {
    clearTimeout(timer);
    exitCode === 0 ? resolve() : reject(new Error(`Exit ${exitCode}`));
  });
});
writeFileSync(
  "docs/demo.cast",
  [
    JSON.stringify({
      version: 2,
      width: cols,
      height: rows,
      timestamp: Math.floor(started / 1000),
      env: { TERM: "xterm-256color", SHELL: "/bin/sh" },
      title: "UCP Inspector - offline fixture and replay",
    }),
    ...events.map((e) => JSON.stringify(e)),
  ].join("\n") + "\n",
);
await sharp(Buffer.from(snapshot)).png().toFile("docs/terminal.png");
terminal.dispose();
rmSync(dir, { recursive: true, force: true });
console.log(
  "Recorded docs/demo.cast and rendered docs/terminal.png from actual terminal output.",
);

