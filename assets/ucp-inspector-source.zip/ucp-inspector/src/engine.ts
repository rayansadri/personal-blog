export const VERSION = '2026-01-23';
export const profile = {ucp:{version:VERSION,services:{'dev.ucp.shopping':[{version:VERSION,spec:`https://ucp.dev/${VERSION}/specification/overview`,transport:'rest',endpoint:'https://merchant.example/ucp/v1',schema:`https://ucp.dev/${VERSION}/services/shopping/openapi.json`}]},capabilities:{'dev.ucp.shopping.checkout':[{version:VERSION,spec:`https://ucp.dev/${VERSION}/specification/checkout`,schema:`https://ucp.dev/${VERSION}/schemas/shopping/checkout.json`}]},payment_handlers:{}}};
export const catalog = [
  {sku:'SNK-BLK-42',title:'Black Sneaker',color:'black',size:42,price:8900,currency:'CAD'},
  {sku:'SNK-WHT-42',title:'White Sneaker',color:'white',size:42,price:7900,currency:'CAD'},
  {sku:'SNK-BLK-PRO',title:'Black Runner Pro',color:'black',size:42,price:12900,currency:'CAD'}
];
export type Step = {name:string;kind:'UCP fixture'|'Local orchestration';status:'OK'|'ERROR'|'SKIPPED';durationMs:number;request:unknown;response:unknown;detail:string};
export type Trace = {id:string;created:string;mode:'offline';fixture:'sneaker-toronto';maxDays:number;steps:Step[];totalMs:number;replayOf?:string};
export const stepNames=['Capability discovery','Product selection','checkout.create','checkout.update','Delivery constraint','Checkout handoff'];
export function createTrace(maxDays=5):Trace {
  if(!Number.isInteger(maxDays)||maxDays<1||maxDays>30) throw new Error('Delivery window must be an integer from 1 to 30');
  return {id:`tr_${globalThis.crypto.randomUUID()}`,created:new Date().toISOString(),mode:'offline',fixture:'sneaker-toronto',maxDays,steps:[],totalMs:0};
}
export function executeStep(trace:Trace):Step {
  const index=trace.steps.length;
  if(index>=stepNames.length) throw new Error('Trace complete');
  const start=performance.now();
  let request:unknown,response:unknown,detail='',status:Step['status']='OK';
  let kind:Step['kind']='Local orchestration';
  const item=catalog.find(c=>c.color==='black'&&c.price<10000)!;
  if(index===0){kind='UCP fixture';request={method:'GET',path:'/.well-known/ucp',network:false};response=profile;detail='Read fixture merchant profile';}
  if(index===1){request={color:'black',budgetMinor:10000,currency:'CAD'};response={product:item};detail='Filter local catalog / under CAD 100';}
  if(index===2){kind='UCP fixture';request={operation:'checkout.create',currency:'CAD',line_items:[]};response={id:'demo_checkout',status:'incomplete',currency:'CAD',line_items:[]};detail='Create in-memory session / no HTTP request';}
  if(index===3){kind='UCP fixture';request={operation:'checkout.update',id:'demo_checkout',line_items:[{item:{id:item.sku},quantity:1}]};response={id:'demo_checkout',line_items:[{item,quantity:1}],subtotalMinor:item.price};detail='Select Black Sneaker / size 42';}
  if(index===4){const fits=9<=trace.maxDays;request={destination:{city:'Toronto',country:'CA'},deliveryMaxDays:trace.maxDays,sku:item.sku};response={availableOptions:[{method:'Standard',minDays:7,maxDays:9,costMinor:999,currency:'CAD'}],eligible:fits,...(!fits?{error:{code:'DELIVERY_CONSTRAINT',message:`Requested delivery ≤ ${trace.maxDays} days; only 7–9 days available.`}}:{selected:'Standard'})};status=fits?'OK':'ERROR';detail=fits?'Standard shipping meets the delivery window':`Requested ≤ ${trace.maxDays} days; available 7–9 days`;}
  if(index===5){const blocked=trace.steps.some(s=>s.status==='ERROR');status=blocked?'SKIPPED':'OK';request={operation:'prepare_handoff',completePurchase:false};response={handoffPrepared:!blocked,orderPlaced:false,reason:blocked?'Delivery constraint unresolved':'Offline handoff only. No payment or order API.'};detail=blocked?'Blocked by delivery constraint':'Prepared offline handoff / no order placed';}
  const durationMs=Math.round((performance.now()-start)*1000)/1000;
  const step={name:stepNames[index],kind,status,durationMs,request,response,detail};
  trace.steps.push(step);trace.totalMs=Math.round(trace.steps.reduce((n,s)=>n+s.durationMs,0)*1000)/1000;
  return step;
}
export function runFixture(maxDays=5):Trace {const trace=createTrace(maxDays);while(trace.steps.length<stepNames.length)executeStep(trace);return trace;}
export function replay(trace:Trace,maxDays=trace.maxDays):Trace {if(trace.mode!=='offline'||trace.fixture!=='sneaker-toronto')throw new Error('Only known offline fixture traces can be replayed');const next=runFixture(maxDays);next.replayOf=trace.id;return next;}
export function diff(a:Trace,b:Trace){return stepNames.flatMap((name,i)=>{const before=a.steps[i],after=b.steps[i];return JSON.stringify([before?.status,before?.request,before?.response])===JSON.stringify([after?.status,after?.request,after?.response])?[]:[{step:name,before:before||null,after:after||null}];});}
