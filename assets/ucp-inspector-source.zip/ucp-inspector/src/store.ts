import {mkdirSync,writeFileSync,renameSync,readFileSync,readdirSync,statSync,lstatSync} from 'node:fs';
import {join} from 'node:path';
import {homedir} from 'node:os';
import {randomUUID} from 'node:crypto';
import {z} from 'zod';
import type {Trace} from './engine.js';
const sensitive=/authorization|cookie|token|secret|password|email|phone|address|buyer|payment|card|credential|api.?key/i;
export function redact(value:unknown):unknown {if(Array.isArray(value))return value.map(redact);if(value&&typeof value==='object')return Object.fromEntries(Object.entries(value).map(([key,v])=>[key,sensitive.test(key)?'[REDACTED]':redact(v)]));if(typeof value==='string')return value.replace(/Bearer\s+\S+/gi,'Bearer [REDACTED]').replace(/[\w.+-]+@[\w.-]+\.[A-Za-z]{2,}/g,'[REDACTED EMAIL]').replace(/\b(?:\d[ -]*?){13,19}\b/g,'[REDACTED NUMBER]').replace(/([?&](?:token|key|secret|password|api_key)=)[^&#\s]+/gi,'$1[REDACTED]');return value;}
const traceSchema=z.object({id:z.string().regex(/^tr_[\w-]+$/),created:z.string().datetime(),mode:z.literal('offline'),fixture:z.literal('sneaker-toronto'),maxDays:z.number().int().min(1).max(30),totalMs:z.number().nonnegative(),steps:z.array(z.object({name:z.string(),kind:z.enum(['UCP fixture','Local orchestration']),status:z.enum(['OK','ERROR','SKIPPED']),durationMs:z.number().nonnegative(),request:z.unknown(),response:z.unknown(),detail:z.string()})),replayOf:z.string().optional()});
export class TraceStore {
  constructor(public dir=process.env.UCP_TRACE_DIR||join(homedir(),'.ucp-inspector','traces')){mkdirSync(dir,{recursive:true,mode:0o700});if(lstatSync(dir).isSymbolicLink())throw new Error('Trace directory must not be a symlink');}
  save(trace:Trace){const safe=traceSchema.parse(redact(trace));const path=join(this.dir,`${safe.id}.json`);const tmp=`${path}.${randomUUID()}.tmp`;writeFileSync(tmp,JSON.stringify(safe,null,2),{mode:0o600,flag:'wx'});renameSync(tmp,path);return safe.id;}
  read(id:string):Trace {if(id==='latest'){const files=readdirSync(this.dir).filter(f=>/^tr_[\w-]+\.json$/.test(f)).sort((a,b)=>statSync(join(this.dir,b)).mtimeMs-statSync(join(this.dir,a)).mtimeMs);if(!files.length)throw new Error('No traces saved. Run a fixture first.');id=files[0].slice(0,-5);}if(!/^tr_[\w-]+$/.test(id))throw new Error('Invalid trace ID');const path=join(this.dir,`${id}.json`);if(lstatSync(path).isSymbolicLink())throw new Error('Trace must not be a symlink');return traceSchema.parse(JSON.parse(readFileSync(path,'utf8'))) as Trace;}
  recordDiscovery(result:unknown){const path=join(this.dir,`discovery_${randomUUID()}.json`);writeFileSync(path,JSON.stringify(redact(result),null,2),{mode:0o600,flag:'wx'});return path;}
}
