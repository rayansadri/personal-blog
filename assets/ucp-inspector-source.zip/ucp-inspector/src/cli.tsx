#!/usr/bin/env node
import React,{useState} from 'react';
import {render,Box,Text,useInput,useApp} from 'ink';
import {Command} from 'commander';
import {runFixture,replay,diff,type Trace} from './engine.js';
import {TraceStore,redact} from './store.js';
import {discover} from './protocol.js';
function Terminal({initial,store}:{initial:Trace;store:TraceStore}){
  const [trace,setTrace]=useState(initial),[prior,setPrior]=useState<Trace|null>(null),[selected,select]=useState(4),[view,setView]=useState('payload'),[history,setHistory]=useState(['run --fixture sneaker-toronto']);
  const {exit}=useApp();
  useInput((input,key)=>{if(input==='q'||key.escape)exit();if(input==='j'||key.downArrow)select(n=>Math.min(5,n+1));if(input==='k'||key.upArrow)select(n=>Math.max(0,n-1));if(input==='p'||key.return)setView(v=>v==='payload'?'summary':'payload');if(input==='d')setView('diff');if(input==='r'||input==='9'){const next=replay(trace,input==='9'?9:trace.maxDays);store.save(next);setPrior(trace);setTrace(next);setHistory(h=>[...h,`replay --offline --max-days ${next.maxDays}`]);}});
  const width=process.stdout.columns||110;
  const payload=view==='diff'?(prior?diff(prior,trace):{message:'Replay first to compare.'}):trace.steps[selected];
  return <Box flexDirection="column" padding={1}><Text color="magenta" bold>{'> UCP INSPECTOR'}</Text><Text dimColor>Trace agentic commerce from your terminal. / OFFLINE FIXTURE</Text><Box borderStyle="round" borderColor="gray" marginTop={1} flexDirection={width<95?'column':'row'}><Box flexDirection="column" padding={1} width={width<95?undefined:'52%'}><Text color="magenta">$ ucp-inspector run --fixture sneaker-toronto</Text><Text dimColor>Black sneakers / CAD 100 / Toronto / {trace.maxDays} days</Text>{trace.steps.map((s,i)=><Box key={s.name} flexDirection="column" marginTop={1}><Text color={i===selected?'magenta':s.status==='ERROR'?'red':s.status==='OK'?'green':'gray'}>{i===selected?'>':' '} {i+1}. {s.name} [{s.status}]</Text><Text dimColor>  {s.detail}</Text><Text dimColor>  {s.kind} / {s.durationMs.toFixed(3)} ms</Text></Box>)}<Text color="green">{'\nSAFE REPLAY / NO REAL ORDERS'}</Text></Box><Box flexDirection="column" padding={1} width={width<95?undefined:'48%'}><Text color="magenta">{view.toUpperCase()}</Text><Text>{view==='summary'?trace.steps[selected].detail:JSON.stringify(payload,null,2)}</Text></Box></Box><Text dimColor>{trace.id}</Text><Text>j/k select · p/enter payload · r replay · 9 resolve delivery · d diff · q exit</Text><Text dimColor>History: {history.slice(-3).join(' → ')}</Text></Box>;
}
const program=new Command().name('ucp-inspector').description('Local UCP traces and safe offline replay').version('0.1.0');
const print=(value:unknown)=>console.log(JSON.stringify(redact(value),null,2));
function fixture(options:{maxDays?:string;json?:boolean;fixture?:string},interactive=false){if(options.fixture&&options.fixture!=='sneaker-toronto')throw new Error('Unknown fixture');const trace=runFixture(Number(options.maxDays||5)),store=new TraceStore();store.save(trace);if(interactive&&process.stdin.isTTY&&process.stdout.isTTY&&!options.json)render(<Terminal initial={trace} store={store}/>);else print(trace);}
program.command('demo').option('--json').option('--max-days <days>','Delivery constraint','5').action(o=>fixture(o,true));
program.command('run').requiredOption('--fixture <name>').option('--max-days <days>','Delivery constraint','5').action(o=>fixture(o));
program.command('discover <endpoint>').option('--record','Save a redacted record of this GET').action(async(endpoint,o)=>{const result=await discover(endpoint);if(o.record)new TraceStore().recordDiscovery(result);print(result);});
for(const command of ['trace','inspect'])program.command(`${command} <id>`).action(id=>print(new TraceStore().read(id)));
program.command('replay <id>').option('--offline','Offline is the only supported replay mode').option('--max-days <days>').action((id,o)=>{const store=new TraceStore(),old=store.read(id),next=replay(old,o.maxDays?Number(o.maxDays):old.maxDays);store.save(next);print(next);});
program.command('diff <a> <b>').action((a,b)=>{const store=new TraceStore();print(diff(store.read(a),store.read(b)));});
program.parseAsync().catch(error=>{console.error(`UCP Inspector: ${error.message}`);process.exitCode=1;});
