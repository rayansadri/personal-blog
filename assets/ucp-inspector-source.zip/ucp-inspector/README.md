# UCP Inspector

Trace agentic commerce from your terminal.

A local-first TypeScript debugging tool: discover a merchant profile, inspect structured execution steps, replay an offline checkout fixture, and compare the results.

## Run locally

Requires Node.js 22 or newer. This package is not published to npm. Do not use an unrelated package with the same name.

```sh
cd ucp-inspector
npm ci
npm test
npm run build
node dist/cli.js demo
```

Optional: `npm link` exposes `ucp-inspector` on your PATH.

```sh
ucp-inspector run --fixture sneaker-toronto
ucp-inspector trace latest
ucp-inspector inspect <trace-id>
ucp-inspector replay <trace-id> --offline
ucp-inspector replay <trace-id> --offline --max-days 9
ucp-inspector diff <first-id> <second-id>
ucp-inspector discover https://your-authorized-merchant.example
ucp-inspector discover https://your-authorized-merchant.example --record
```

`demo --json` produces machine-readable output. In a terminal, j/k navigate, Enter or p toggles payloads, r replays, 9 widens the delivery window, d compares the previous trace, and q exits. The expected fixture failure is a valid completed trace; invalid commands and runtime errors exit nonzero.

## What really runs

The fixture filters three fictional products for black sneakers under CAD 100, creates an in-memory session, adds size 42, evaluates shipping and prepares a handoff only if eligible. Standard shipping takes 7–9 days, so the default five-day request fails. Replay with nine days succeeds. Neither path places an order. Step timings measure execution, not animation delays or network latency.

The browser demo runs the same `src/engine.ts` code as the CLI. It is explicitly simulated. No API keys, live merchant connections, payment processing or external services are needed.

## Live discovery scope

`discover` makes exactly one HTTPS GET to `/.well-known/ucp`. It rejects redirects, caps response size at 1 MB and times out after eight seconds. `--record` opts into recording this client's discovery result; it does not intercept other agents.

The Zod validator implements a **subset** of the [UCP 2026-01-23 profile specification](https://ucp.dev/2026-01-23/specification/overview/): profile version, transport requirements, capability metadata and namespace authority. It intersects supported capability versions and prunes orphan extensions. Other protocol versions are rejected. This is not full UCP certification; it does not fetch or validate operation schemas, execute merchant checkout endpoints, or support every extension. Session fixtures are illustrative, not wire-format conformance tests. No live merchant endpoint was used during automated tests.

No Shopify adapter is implemented. A future authorized adapter needs separately scoped credentials and tests; no production write path is included here.

## Architecture

```text
Configured merchant → read-only GET → profile validation → negotiation
                                             └→ optional redacted record

Fictional catalog → shared fixture engine → structured trace
                                             ├→ Ink terminal inspector
                                             ├→ portfolio browser demo
                                             └→ offline replay → diff
```

CLI: Commander + Ink/React. Validation: Zod. Persistence: JSON files under `~/.ucp-inspector/traces`, or `UCP_TRACE_DIR`. Browser traces are in memory and exportable as JSON. There is no automatic browser persistence.

## Safety and limitations

- All replay is offline. There are no payment or order-write calls.
- Saved traces redact sensitive key names, emails, bearer credentials and common card-like numbers. Redaction is best-effort, not a guarantee for arbitrary free text. Inspect exports before sharing.
- Trace files use owner-only permissions. IDs are validated before reads.
- Delivery, search and handoff are local orchestration, not invented standard UCP tools.
- The CLI does not prove adoption, production use, conversion lift or merchant compatibility.
- The discovery recorder is for your explicitly configured endpoint, not arbitrary traffic interception.

## Tests

`npm test` builds the CLI and covers fixture errors, safe replay, diffing, profile discovery/validation, negotiation, redaction, persistence and CLI execution end to end. Website interaction tests live at `../scripts/test-ucp-demo.mjs`.

## Portfolio and recording

Open `../work/ucp-inspector/index.html` for the interactive case study. The homepage retains its existing Work timeline with UCP Inspector added after GTM MCP.

`docs/demo.cast` is an actual Ink PTY recording (play with asciinema), and `docs/terminal.png` is rasterized from its terminal cells. The development capture script reuses the sibling GTM MCP tooling; it is not required to run the CLI.

## License

MIT. No public GitHub repository or npm release has been created.
